package com.example.productive

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
